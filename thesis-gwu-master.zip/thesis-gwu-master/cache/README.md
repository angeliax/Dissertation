This directory is for tikz externalization

Look at Ch 50 of the tikz documentation

http://ctan.math.utah.edu/ctan/tex-archive/graphics/pgf/base/doc/pgfmanual.pdf
